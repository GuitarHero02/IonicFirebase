using System;
using WPCordovaClassLib.Cordova.Commands;

namespace Cordova.Extension.Commands
{
	public class CustomUriMapperCommand : BaseCommand
	{
	}
}